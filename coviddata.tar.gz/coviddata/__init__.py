__all__ = ['data', 'query']


from coviddata.data import report, population
from coviddata.query import query, Query
